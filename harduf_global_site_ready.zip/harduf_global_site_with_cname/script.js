
console.log("Harduf Global site loaded successfully.");
